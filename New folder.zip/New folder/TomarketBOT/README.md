# TOMARKET Bot

Register Here : [TOMARKET Bot](https://t.me/Tomarket_ai_bot/app?startapp=0000008H)

Tutorial in my Telegram Group : [S4NSGroup](https://t.me/sansxgroup)


## Features
- Auto Claim Bot
- Auto Clear Task
- Auto Play Game

