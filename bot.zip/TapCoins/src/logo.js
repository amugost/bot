function printLogo(){
    console.log(`
    ██████╗ ██╗   ██╗████████╗██╗ ██████╗ ██████╗  ██████╗ ██╗      
    ██╔══██╗██║   ██║╚══██╔══╝██║██╔════╝██╔═══██╗██╔═══██╗██║      
    ██████╔╝██║   ██║   ██║   ██║██║     ██║   ██║██║   ██║██║      
    ██╔═══╝ ██║   ██║   ██║   ██║██║     ██║   ██║██║   ██║██║      
    ██║     ╚██████╔╝   ██║   ██║╚██████╗╚██████╔╝╚██████╔╝███████╗ 
    ╚═╝      ╚═════╝    ╚═╝   ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝ 
            `.cyan);
    console.log('[+] Welcome & Enjoy Sir !'.green);
    console.log('[+] Error? PM Telegram [https://t.me/NothingYub]'.red);
    console.log('[+] 📣 New Feature Update 📣  [https://t.me/puticoolbot]'.blue);
}
module.exports = printLogo;