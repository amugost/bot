GUILD_ID = "boraa"
REFERRAL_CODE = "T53XMF" #change to your refferal code