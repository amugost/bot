# WONTON BOT

## LINK BOT: [Register Here](https://t.me/WontonOrgBot/gameapp?startapp=referralCode=YR397O44)
## TUTORIAL IN GROUP : [Join Here](https://t.me/sansxgroup)

## Features
- Auto Farming
- Auto Clear Task
- Auto Play Game Max Score