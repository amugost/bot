# FINTOPIO BOT

## LINK BOT: [Register Here](https://t.me/fintopio/wallet?startapp=reflink-reflink_uJDicn0uMJ4LvCvc-)
## TUTORIAL IN GROUP : [Join Here](https://t.me/sansxgroup)