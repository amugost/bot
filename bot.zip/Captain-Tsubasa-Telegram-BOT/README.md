### Captain Tsubasa Auto BOT SCRIPT


**Link Captain Tsubasa:** [Click Here](https://t.me/TsubasaRivalsBot/start?startapp=inviter_id-1416732111)

✔️ Auto tap  
✔️ Auto tasks  
✔️ Auto card upgrades  
✔️ Prioritize upgrading high-profit cards first
✔️ Auto daily check-in

Toggle upgrades (true or false) and set the maximum upgrade cost in `config.json`.


```json
{
  "enableCardUpgrades": true,
  "maxUpgradeCost": 1000,
}
```

**Instructions:**

**NODEJS MUST BE INSTALLED.**

Run the following command to install the necessary modules:

```bash
npm install
```



Edit two files: `data.txt` and `proxy.txt`.

For those using multiple accounts, it's recommended to use a proxy (if using one account, no need to create the `proxy.txt` file).

**Proxy format:** `http://user:pass@ip:port`


In the `data.txt` file, the format should be:

`query_id=xxxx` or `user=xxxx`

sourcecode:dancayairdrop


Run the tool with the command:

`node tsubasa.js` or `node tsubasa-proxy.js`


Join my Telegram: [LINK HERE](https://t.me/scriptsharing)
