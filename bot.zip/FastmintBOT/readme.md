# FASTMINT BOT

## LINK BOT: [Register Here](https://t.me/fastmintapp_bot?start=6057140648)
## TUTORIAL IN GROUP : [Join Here](https://t.me/sansxgroup)

## Features
- Auto Clear Task
- Autofarm
- Auto Create & Backup Wallet